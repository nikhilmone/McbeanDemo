package custom.mbean;
public interface MyServerMonitorMBean
  {
  }
