package custom.mbean;
import javax.management.*;
import java.io.*;
import java.util.*;
import java.rmi.*;
import javax.naming.*;
import org.apache.log4j.*;
import org.apache.log4j.xml.DOMConfigurator;

public class MyServerMonitor implements MyServerMonitorMBean
  {
      public MyServerMonitor()
      {
		System.out.println ("RUFE McBean auf!");
		InputStream is = this.getClass().getClassLoader().getResourceAsStream("mylog4j.xml");
		if (is != null ) {
			System.out.println ("mylog4j.xml wurde gefunden!"); 
		} else  { 
			System.out.println ("mylog4j.xml wurde NICHT gefunden!");
		}
                System.out.println ("Going to Call  ===>  LogManager.resetConfiguration()");  
		LogManager.resetConfiguration();
		//DOMConfigurator.configure(this.getClass().getClassLoader().getResource("mylog4j.xml"));
      }

  }
